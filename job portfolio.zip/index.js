

const express = require("express");
const app = express();
const mysql = require("mysql");
const session = require("express-session");
const bodyParser = require("body-parser");


app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var conn = mysql.createConnection({
    host: 'localhost',
    user: "root",
    password: "",
    database: "port"
});

app.set('view engine', 'hbs');



app.get('/c1login', function (req, res) {
    res.render('c1login');
});
app.get('/companies_infos', function (req, res) {
    res.render('companies_infos');
});
app.get('/company_profiles', function (req, res) {
    res.render('company_profiles');
});
app.get('/job_listings1', function (req, res) {
    res.render('job_listings1');
});
app.get('/next-page', function (req, res) {
    res.render('next-page');
});
app.get('/projecttxt final', function (req, res) {
    res.render('projecttxt final');
});
app.get('/projecttxt orignal', function (req, res) {
    res.render('projecttxt orignal');
});
app.get('/registration', function (req, res) {
    res.render('registration');
});
app.get('/sector_education', function (req, res) {
    res.render('sector_education');
});
app.get('/sector_fashion', function (req, res) {
    res.render('sector_fashion');
});
app.get('/sector_finance', function (req, res) {
    res.render('sector_finance');
});
app.get('/sector_healthcare', function (req, res) {
    res.render('sector_healthcare');
});
app.get('/sector_technology', function (req, res) {
    res.redirect('sector_technology');
});

app.get('/signup', function (req, res) {
    res.render('signup');
});

app.get('/subscription', function (req, res) {
    res.render('subscription');
});
app.get('/validation', function (req, res) {
    res.render('validation');
});



app.post('/signup', function (req, res) {
    const name = req.body.username;
   
    const password = req.body.pass;
    const confirmPassword = req.body.confirmpass;
    const phone = req.body.phone;

    if (password !== confirmPassword) {
        return res.render('signup', { message: 'Passwords do not match' });
    }

    var sql = `SELECT email FROM useres WHERE email = ?`;
    conn.query(sql, [email], function (error, result) {
        if (error) {
            console.error(error);
            return res.render('signup', { message: 'Error occurred' });
        }

        if (result.length > 0) {
            return res.render('signup', { message: 'Email is already in use' });
        }

        var insertSql = `INSERT INTO useres (Name, email, password, phoneno) VALUES (?, ?, ?, ?)`;
        conn.query(insertSql, [name, email, password, phone], function (insertError, insertResult) {
            if (insertError) {
                console.error(insertError);
                return res.render('signup', { message: 'Error occurred during registration' });
            }
            return res.render('signup', { message: 'User registered successfully' });
        });
    });
});



app.get('/c1login', function (req, res) {
    res.render('c1login');
});
app.post('/c1login', function (req, res) {
    const username = req.body.username;
    const pass = req.body.pass;
    const qualification = req.body.qualification;
    const cv = req.body.cv;
    const expectedjob = req.body.expectedjob;
    const expectedsalary = req.body.expectedsalary;
    const experience = req.body.experience;

    if (email && password) {
        var insertSql = `INSERT INTO user (id, username, pass, qualification,cv,expectedjob,expectedsalary,experience) VALUES (?, ?, ?, ?,?,?,?,?)`;
        conn.query(insertSql, [id, username, pass, qualification,cv,expectedjob,expectedsalary,experience], function (insertError, insertResult) {
            if (err) {
                console.error(err);
                res.render('c1login', { message: 'An error occurred. Please try again.' });
            } else if (result.length > 0) {
                var user = result[0];
                req.session.loggedin = true;
                req.session.email = email;
                req.session.userId = user.id; 
        
                res.redirect('/index');
            } else {
                res.render('c1login', { message: 'Incorrect email or password.' });
            }
        });
    } else {
        res.render('c1login', { message: 'Please enter email and password.' });
    }
});



app.get('/index', function (req, res) {
    if (req.session.loggedin) {
        res.render('index', { user: req.session.email });
    } else {
        res.redirect('/login'); 
    }
});



app.post('/contact', function(req, res) {
    var name = req.body.name;
    var phoneNumber = req.body.phone;
    var donation = req.body.donation;
    var address = req.body.address;
    var message=req.body.message;
    var sellerId = req.session.userId; 

    var sql = "INSERT INTO contact (userid,name,phoneno,donation, address, message) VALUES (?, ?, ?, ?, ?,?)";
    conn.query(sql, [sellerId,name, phoneNumber, donation,address,message], function(err, result) {
        if (err) {
            console.error("Error inserting data into contact table:", err);
            res.send("Error submitting form. Please try again.");
        } else {
            res.send("form is submitted");
        }
    });
});
app.get('/fetchContact', function(req, res) {
    
    var sql = "SELECT * FROM contact ";
    conn.query(sql, function(err, results) {
        if (err) {
            console.error("Error retrieving data from contact table:", err);
            res.status(500).json({ error: "Error retrieving data" });
        } else {
            res.json(results);
        }
    });
});
app.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err) {
            console.error(err);
        }
        res.redirect('/login');
    });
});
app.post('/Donate_Footwear', function(req, res) {
    var name = req.body.name;
    var address = req.body.address;
    var city = req.body.city;
    var type = req.body.type;
    var quality=req.body.quality;
    var footwearsize =req.body.footwearsize;
    var sellerId = req.session.id; 

    var sql = "INSERT INTO footware (name,address,city, type, quality,footwearsize) VALUES ( ?, ?, ?, ?,?,?)";
    conn.query(sql, [name, address, city,type,quality,footwearsize], function(err, result) {
        if (err) {
            console.error("Error inserting data into footware table:", err);
            res.send("Error submitting form. Please try again.");
        } else {
            res.send("form is submitted");
        }
    });
});
app.get('/fetchFootware', function(req, res) {
    var sql = "SELECT * FROM footware";
    conn.query(sql, function(err, results) {
        if (err) {
            console.error("Error retrieving data from footware table:", err);
            res.status(500).json({ error: "Error retrieving data" });
        } else {
            res.json(results);
        }
    });
});
app.get('/footwear', function(req, res) {
    var sql = "SELECT * FROM footware";
    conn.query(sql, function(err, results) {
        if (err) {
            console.error("Error retrieving data from footware table:", err);
            res.render('error', { message: "Error retrieving data. Please try again." });
        } else {
            res.render('footwear', { footware: results });
        }
    });
});

app.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err) {
            console.error(err);
        }
        res.redirect('/login');
    });
});

app.listen(20000, () => {
    console.log('Server is running on port 20000');
});
